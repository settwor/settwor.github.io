# SETTWOR site: version history

Every change of the site raises the version. The archive is named `settwor-site-vX.Y.zip`.

Older entries (before 8.9): `history/CHANGELOG-ARCHIVE.md` in the bundle root (not part of the site, not required reading).

## 11.17 (CDRA award plaques on the home page)
- Owner request: tie SETTWOR and CDRA together with the new CDRA widget (iframe plaques from `https://cdras.github.io/EMBED.html`).
- New `_includes/cdra-awards.html`: home page section "CDRA awards" (heading row with the link "All awards" to `https://cdras.github.io/`, one sentence that CDRA is SETTWOR's own award and not an official certification, three plaques: GOT ME UP 2 (1,000,000), GET IT, Vol.1 (1,000,000), SETTWOR (2,500,000)). File names, titles and ratios are copied from the code on EMBED.html (live page checked on 29 October 2026, CDRA v1.16.17). A new award = one more `include cdra-plaque.html` line.
- New `_includes/cdra-plaque.html`: one plaque = two iframes (light and dark). No script, no cookies; the rule that only `tilt.js`-style site scripts exist is not touched.
- `index.html`: `{% include cdra-awards.html %}` at the very bottom of the home page, after the questions (FAQ) and before the structured data (owner request: lower them to the bottom).
- `css/main.css`, section 11.17: grid of plaques (`minmax(min(100%, 300px), 1fr)`, plaque max width 504 px); the light iframe is shown on a light theme, the dark one on a dark theme (system theme without `data-theme`, otherwise the footer switch). `sw.js` VERSION v99 -> v100 because the CSS changed.
- `privacy.html`: the "Embedded content" line also names the CDRA plaques (no script, no cookies, GitHub may get technical data).
- Not changed: the footer link to CDRA and `sameAs` (10.0), the artist node (11.14 to 11.16).
- Not tested: real Jekyll and a real browser (no network here for the build; the live plaques load only on the published site). Checked by reading only: the Liquid of the includes, the CSS selectors.
- Changed files: `_includes/cdra-awards.html` (new), `_includes/cdra-plaque.html` (new), `_includes/site-version.html`, `index.html`, `css/main.css`, `privacy.html`, `sw.js`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.16 (artist node: three more profile links, entity rule fixed)
- Owner request: fix the rule about the one artist entity and add the missing profile links.
- `_includes/person-jsonld.html`: `pj_extra` got Apple Music (`https://music.apple.com/us/artist/settwor/1526983418`), YouTube Music (`https://music.youtube.com/@SETTWOR`) and YouTube (`https://www.youtube.com/@SETTWOR`), so the artist has ten extra profiles besides `links.follow` and `links.elsewhere`. `pj_have` now also holds `au_apple`, `au_pandora` and `au_ytm` (set by `artist-urls.html`, which is not in this archive), so an address that the defaults already print is not printed again. Exact-text check only: if `artist-urls.html` writes the same profile in a different form, it still appears twice, so look at `sameAs` in the page source.
- Rule (wording fixed in `AI-NOTES.md`, rule 11, and in the comment of `person-jsonld.html`): ONE `MusicGroup` with the one `@id` `https://settwor.github.io/#artist`, with `sameAs` for all profiles. Ledgertone and CDRA refer to it by that `@id` as `creator`/`founder` and never redefine the type. Google says that no special machine-readable files or markup are needed for Search or its AI features, and that `llms.txt` brings nothing and does no harm. So the markup is for an unambiguous entity, not for a boost, and no `llms.txt` is made.
- CDRA (not in this archive): its JSON-LD must have `"creator": {"@id": "https://settwor.github.io/#artist"}` and must not redefine the type. The same line is in `docs/SEO.md` of Ledgertone.
- Old note fixed: the 9.3 hint in `AI-NOTES.md` said the artist is ONE `Person` and never a `MusicGroup`; that is outdated since 11.14.
- Not tested: real Jekyll and the Rich Results Test (no Liquid engine and no network here). After publishing check the home page source: `sameAs` has no empty entries, no double commas and no address twice.
- Changed files: `_includes/person-jsonld.html`, `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.15 (artist node: seven more profile links, main genres)
- Owner request: add the missing profile links to the artist entity and make sure the main genres are Brazilian Phonk and Phonk.
- `_includes/person-jsonld.html`: `sameAs` got seven profiles given by the owner: Shazam, MusicBrainz, Musixmatch, Genius, Deezer, Amazon Music, TikTok. Each one is printed only if the same address is not already in `_data/links.yml` (`follow`, `elsewhere`), checked with the string `pj_have`, so no address appears twice if the owner adds it in Pages CMS later.
- `genre` is now `["Brazilian Phonk", "Phonk"]` (was Phonk, Brazilian funk, Electronic dance music). `knowsAbout` starts with Brazilian Phonk, Phonk; the other topics stay there.
- Not changed on purpose: the `description` text (it still says "phonk, Brazilian funk and dance/electronic music"; it is the same sentence as on the visible pages, the owner decides if it changes), the visible lists of channels (`_data/links.yml`, `artist-urls.html`) and the footer: they are not in this archive.
- Not tested: real Jekyll and Google Rich Results Test (no Liquid engine and no network here). Check the home page source after publishing: `sameAs` has no empty entries and no double commas.
- Changed files: `_includes/person-jsonld.html`, `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.14 (artist node: MusicGroup instead of Person)
- Owner decision: the artist is a `MusicGroup` (the stage project), not a `Person`. One `@id` (`https://settwor.github.io/#artist`) stays, so Ledgertone and CDRA can point to it.
- `_includes/person-jsonld.html`: `@type` is `MusicGroup`. Removed the Person-only fields `jobTitle`, `birthDate`, `birthPlace`, `nationality`, `homeLocation` (invalid on MusicGroup). Added `location` (Poland) and `genre`. `sameAs`, `subjectOf`, `alternateName`, `description`, `knowsAbout` unchanged.
- `_includes/article-jsonld.html`: `author` and `publisher` are `MusicGroup` with the same `@id` (two types for one `@id` would conflict).
- Comments only: `profile-jsonld.html`, `ledgertone-jsonld.html`.
- Not done: no `foundingDate` (the start is ambiguous: channel 2020, first release 2021; ask the owner). CDRA and Ledgertone code is not in this archive: they must reference `https://settwor.github.io/#artist` as `creator`.
- Not tested: Google Rich Results Test (no network). Run it on the home page, `bio.html` and one news article after publishing.
- Changed files: `_includes/person-jsonld.html`, `_includes/article-jsonld.html`, `_includes/profile-jsonld.html`, `_includes/ledgertone-jsonld.html`, `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.13 (photos: order inside one day follows the list)
- Owner request: photos are sorted by date, so photos of one day cannot be put in the order the owner wants.
- New rule: the newest DAY comes first; photos of the same day keep the order of the list in `_data/gallery.yml` (first in the list = first on the page). In Pages CMS the owner drags a photo up or down in the list. Different days still sort by date, so year tabs and the year sections are unchanged.
- `_includes/photos-sorted.html` (new) builds the sorted list (`ph_keys`: date + 7 digits = 2000000 minus the place in the list, sorted as text, then reversed). `_includes/photo-pick.html` (new) turns one entry into the variable `photo`. Why: `sort: "date"` ignores the list order inside one day (Ruby sort is not stable).
- `photo.html`: tabs, grid and the JSON-LD use the new list. `index.html`: the 9 photos on the home page use it too, so both pages agree. `_includes/rail-start.html` was not changed (it only needs the years).
- `.pages.yml`: the hint under "Photographs" now says how the order works.
- Tested with `tools/preview.py` (not real Jekyll): the 68 photos of the live data come out in the expected order; swapping two photos of one day in a test copy swaps them on the page; home page and JSON-LD follow. Not tested in real GitHub Pages: if the build fails, send the log of Actions > "pages build and deployment".
- The data file `_data/gallery.yml` is NOT in the zip (owner's data). Its current order already works: photos of one day show in the order they are in the file.
- This zip also holds everything of 11.12 (favicon). `?v=11.12` in the icon links stays as it is.
- Changed files: `photo.html`, `index.html`, `.pages.yml`, `_includes/photos-sorted.html` (new), `_includes/photo-pick.html` (new), plus the 11.12 files (`_layouts/default.html`, `site.webmanifest`, `favicon-48.png`), `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete. `.pages.yml`: copy it only if you did not change it yourself since 11.11, otherwise change only the `description` line under "Photographs".

## 11.12 (favicon: make Google fetch the new icon again)
- Owner request: replace the logo in Google search with the new favicon, so that Google really changes it.
- Google keeps the old icon until it fetches the icon file again, and it does that rarely. What the site controls: a new address for every icon file, one clear set of icons in the head, a crawlable home page. When it re-reads is Google's decision (days to weeks); nobody can force it.
- `favicon-48.png` (new, root): the 48 px frame cut from the new `favicon.ico`, so the PNG is exactly the same picture.
- `_layouts/default.html`: icon links now end with `?v=11.12` (ico, 48 px png, apple-touch-icon). The 96 px and 192 px `<link rel="icon">` lines are removed from the head on purpose: those files in `images/` were not in the archive, so it was not possible to check that they show the new picture, and Google could pick an old one. The files themselves stay (the manifest uses 192 and 512).
- `site.webmanifest`: icon addresses got `?v=11.12`.
- Not done: `images/favicon-*.png` and `images/apple-touch-icon.png` were not in the archive. The owner must check that they show the NEW picture, and replace them if not (48, 192, 512, 180 on white).
- Not changed on purpose: `sw.js` (pages are network first, icons are not in its cache list), old standalone pages in `lyrics/` and `tracklist/` (they point to `../images/favicon.png`; Google reads the home page icon).
- The owner must do after publishing: Google Search Console > URL inspection > `https://settwor.github.io/` > Request indexing. Check that `https://settwor.github.io/favicon.ico` opens the new picture. Next time the icon changes: raise `?v=` in `_layouts/default.html` and `site.webmanifest`.
- Changed files: `_layouts/default.html`, `site.webmanifest`, `favicon-48.png` (new), `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.11 (weight scale one step down)
- Owner request: every weight one step lighter, the heaviest one becomes the new heaviest; body text and the hero weights stay as already set.
- `css/main.css` section 1: `--fw-bold` 700 -> 600 and `--fw-semibold` 700 -> 600. Every heading, button, label, number and the vibrancy labels (`--vib-weight`) use these tokens, so the whole site follows. Not changed on purpose: body text `--fw-body` 450 and the hero tokens (`--fw-hero-title` 700 on desktop, the phone ones 600).
- Both tokens are now equal (600), as they were both 700 before. To separate them again, change only `--fw-semibold`.
- Elements with `font-weight: normal` (year numbers in platform cards, trend rows) were not touched.
- `sw.js` VERSION v98 -> v99. The version in the footer shows 11.11.
- Not tested on a real phone. Check button and card label widths: lighter letters are slightly narrower.
- Changed files: `css/main.css`, `sw.js`, `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.10 (hero weights: desktop back, phone lighter)
- Owner correction: the lighter hero name and tagline of 11.9 were meant for phones only.
- Desktop is back as before 11.9: name Bold 700 (`--fw-hero-title`), tagline = body weight (`--fw-hero-tagline: var(--fw-body)`, 450).
- Phones (`max-width: 39.99rem` block): name 600 (`--fw-hero-title-phone`, was 700), tagline 600 (`--fw-hero-tagline-phone`, was 700).
- `sw.js` VERSION v97 -> v98. The version in the footer shows 11.10.
- Not tested on a real phone.
- Changed files: `css/main.css`, `sw.js`, `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.9 (hero name and tagline a little lighter)
- Owner request: make the font of the hero texts "SETTWOR" and "Phonk and Brazilian funk producer" slightly thinner.
- `css/main.css` section 1: new tokens `--fw-hero-title: 600` (name, was Bold 700) and `--fw-hero-tagline: 400` (line under the name, was 450 from the body weight). `.hero__title` and `.hero__tagline` use them. In the phone block the tagline was Bold 700; it is now 600 (a fixed number next to the rule).
- `sw.js` VERSION v96 -> v97 (CSS changed). The version in the footer shows 11.9.
- Not tested on a real phone. Check the name at large size: a lighter weight makes the letters a little narrower.
- Changed files: `css/main.css`, `sw.js`, `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.8 (normal text a little lighter)
- Owner request: use a slightly thinner font for normal text across the whole site.
- `css/main.css` section 1: new token `--fw-body: 450`. Body text (`body`) and the "more" link in section heads (`.section-head__more`) use it instead of Medium 500. Headings, buttons, labels and numbers keep Bold, so the contrast between them and the text grows a little. To change the lightness everywhere, edit this one number (400 is Regular, 500 is the old look).
- Geologica is a variable font (100-900), so 450 is a real weight, not rounded to 400 or 500. If the font files are missing, the system font shows and 450 may round to 400.
- `sw.js` VERSION v95 -> v96 (CSS changed). The version in the footer shows 11.8.
- Not tested on a real phone. Check small grey text on the dark theme: thinner strokes can look dimmer.
- Changed files: `css/main.css`, `sw.js`, `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`, `CHANGES.txt`. Nothing to delete.

## 11.7 (footer is reachable on phones)
- Owner report: on a phone the whole footer cannot be scrolled to its end.
- Cause found in the code (not seen on a real phone): the cookie banner (`.consent`) and the notification card (`.push-ask__card`) are `position: fixed` at the bottom and lie over the page, and nothing reserved room under them, so they covered the last footer lines.
- `js/main.js` new section 12: measures the visible banners and sets `--bottom-banner-h` on `<html>` (0 when none). `css/main.css` new section 9.1: `.site-footer` gets that much extra bottom padding.
- `sw.js` VERSION v94 -> v95 (CSS and JS changed). The version in the footer shows 11.7.
- Not tested on a real iPhone or Android. If the footer still stops early with NO banner on screen, the cause is something else: report it with the phone and browser.
- Changed files: `css/main.css`, `js/main.js`, `sw.js`, `VERSION`, `_includes/site-version.html`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 11.6 (Geologica font, Brazilian Phonk place on the home page, site version in the footer)
- Owner request: the site font (a foundry font that was free for personal use only) is replaced by Geologica (SIL Open Font License 1.1, free for commercial use). `fonts.css` has one variable `@font-face` (100-900, Latin + Cyrillic); `css/main.css` section 1 sets `--font-brand: 'Geologica'`; `fonts/OFL.txt` is the licence, `fonts/README.txt` and `tools/make-font-woff2.py` put the font files into `fonts/`. The old font files are deleted. `license.html` got a "Typeface" credit (optional by the licence).
- Owner request: the key line on the home page (`index.html`) now says "No. 13 in Phonk and No. 22 in Brazilian Phonk on Pandora". Both places come from `lt_phonk_place` and `lt_bphonk_place` in the front matter of `top-phonk-artist.html`; the Brazilian part is skipped if that key is empty. The genre is named like in the Ledgertone ranking: Brazilian Phonk.
- Owner request: the footer shows "Site version 11.6" (`_includes/footer.html`, last paragraph). The number lives in `_includes/site-version.html` (Jekyll cannot read the `VERSION` file, which is excluded from the site). From now on, raise BOTH `VERSION` and `_includes/site-version.html` together.
- `sw.js` VERSION v93 -> v94 (CSS and the font changed).
- Not tested: real Jekyll build and the real Geologica files (they are added by the owner, see `fonts/README.txt`). Check header and button widths: Geologica is wider than the old font.
- Changed files: `fonts.css`, `css/main.css`, `fonts/OFL.txt`, `fonts/README.txt`, `tools/make-font-woff2.py`, `index.html`, `license.html`, `_includes/footer.html`, `_includes/site-version.html` (new), `sw.js`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. To delete: every old font file in `fonts/` (all of them except the Geologica files, `OFL.txt` and `README.txt`).

## 11.5 (pull to refresh on phones)
- Owner request: pull the page down on a phone to refresh it, but a quick flick up the page must never refresh it.
- `js/fluid.js` (new section 7, header says v11.5; all numbers are in the object `PULL`): touch only. A pull counts only when ALL is true: the finger went down while the page was already at the very top and had not scrolled for 160 ms; the first clear move is downward and mostly vertical; the round badge is pulled past the mark (64 px of badge travel, about 150 px of finger); it is held there for 180 ms; the whole touch lasted at least 320 ms; the finger is lifted (not cancelled). A touch that starts lower on the page never counts, even if it scrolls to the top while the finger is still down (lift and pull again). Not active: open photo viewer or release window or menu, form fields, the avatar, sideways scrollers, boxes scrolled down. Then the badge shows a spinner for 0.38 s and the page reloads (`location.reload()`, the service worker still serves its own pages). If the reload does not happen in 9 s the badge goes away.
- `css/main.css` (last section): `.ptr` badge (theme tokens, so dark theme follows) and `html.ptr-on { overscroll-behavior-y: contain }` so the browser's own pull-to-refresh does not fire a second time.
- Reduced motion: the badge arrives without travel and the spinner does not turn. The badge has a hidden status text "Refreshing" for screen readers.
- `sw.js` VERSION v92 -> v93 (CSS and JS changed).
- Tested in headless Chromium with emulated touch (CDP): slow pull and hold reloads; fast flick, short pull, no hold at the mark, pull and go back, swipe up, and a drag that starts scrolled and passes the top all do NOT reload. Not felt on a real iPhone or Android: check the mark distance and that Safari's own bounce does not show.
- Changed files: `js/fluid.js`, `css/main.css`, `sw.js`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 11.4 (57 releases, April 2025 place 6 in all languages)
- Owner request: write "57 releases" anyway. `index.html`: new front matter key `releases_total: "57"`; the key line now shows `{{ page.releases_total | default: ft_all.size }}` (the old folder count stays only as a fallback if the key is emptied). "N of them in <year>" is still counted from `_releases`.
- Biographies (content files, NOT in the zip, delivered next to it): `_bio/en.md`, `ru.md`, `pl.md`, `es.md`, `pt.md`, `uk.md`, line 191 only: April 2025 is now place 6 (was places 4 and 5), and the Ledgertone sentence of 27 October 2026 now says place 13 in Phonk and place 22 in Brazilian Phonk (was 10 and 20), to match the new data. Nothing else in the six files changed.
- The home key line takes the Phonk place from `top-phonk-artist.html` (now 13) by itself.
- `sw.js` unchanged (v92). Not tested in real Jekyll.
- Changed files in the zip: `index.html`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 11.3 (top phonk page: April 2025 place)
- Owner correction: in April 2025 he was at place 6 (not "places 4 and 5"). `top-phonk-artist.html`: the sentence in the first block now says "held place 6 among all phonk artists on Pandora". The page is English only; no other language copy of this sentence exists in the zip.
- NOT done: the release count (owner says 57 releases) and any other-language text (`_bio/*.md`, `_data/*.yml`, `_releases`) are content files and are not in the zip (rule 8), so nothing could be checked or changed there. The home callout counts releases from `_releases` itself.
- `sw.js` unchanged (v92). Not tested in real Jekyll.
- Changed files: `top-phonk-artist.html`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 11.2 (top phonk page: new places and totals)
- Owner data: Phonk place 13 of 2,623 artists; Brazilian Phonk place 22 of 1,877 artists (was 10 of 2,759 and 7 of 1,887). The "#6" and "#12" next to them are not used (the ranked counts stay removed).
- `top-phonk-artist.html`: front matter `lt_phonk_place`, `lt_phonk_total`, `lt_bphonk_place`, `lt_bphonk_total` changed, and the hardcoded `seo_title` ("Top 13 Phonk Artist on Pandora, Top 22 in Brazilian Phonk") and `description` (place 13 / place 22). Snapshot date (25 October 2026) and listeners (23,000) are NOT changed: no new values were given.
- `sw.js` unchanged (v92). Not tested in real Jekyll.
- Changed files: `top-phonk-artist.html`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 11.1 (top phonk page: real totals instead of the word "thousands")
- Owner correction of 11.0: not the word "thousands", but the real number. `top-phonk-artist.html` now uses `lt_phonk_total` (2,759) and `lt_bphonk_total` (1,887) in "How to read these numbers", in "Questions" and in the FAQ JSON-LD. The ranked counts (132 / 44) stay removed.
- `sw.js` unchanged (v92). Not tested in real Jekyll.
- Changed files: `top-phonk-artist.html`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 11.0 (top phonk page: no ranked-artist counts)
- Owner brief: remove phrases like "counted among the 132 artists that have a listener number" and "the 132 artists with a listener number"; write "thousands of artists" instead.
- `top-phonk-artist.html`: the clause is removed from the two list items in "The numbers" (they now end with "artists in the genre", the genre totals stay); "How to read these numbers" and the two answers in "Questions" (and the same two answers in the FAQ JSON-LD) now say "among thousands of artists" / "among thousands of phonk artists on Pandora". The front matter keys `lt_phonk_ranked` and `lt_bphonk_ranked` are deleted because nothing uses them any more (the owner no longer has to update them with a new snapshot).
- `sw.js` unchanged (v92): no CSS or JS changed.
- Not tested in real Jekyll (checked by text search: no `_ranked` and no "listener number" left on the site).
- Changed files: `top-phonk-artist.html`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 10.9 (Streams page: chart shows plays of each year)
- Owner brief: the line chart must show how many plays there were in EACH year, not the running total; make it look good.
- `_includes/stats-trend.html` rewritten: per year the plays of all music platforms are added (no running total); one point per year from the first to the last year with numbers; the line is scaled to the busiest year (8 percent free at the top) and that year's dot is filled. Heading is now "Plays by year" / "Music platforms, plays in each year". Hidden when fewer than two years have numbers.
- "Earlier" is not a year, so it is no longer a point of the line; it is shown as the last plain row of the list (only when it has numbers).
- The list under the chart: newest year first, a thin bar (share of the busiest year) and the full number with commas (rule 4: no rounding). The "+gain" column of 10.8 is removed. Built without the Liquid `reversed` loop (the preview emulator has none).
- `css/main.css`: section 10.9 replaces the list styles of 10.8 (grid row: year, bar, number; peak row in bold; bars grow with the line when the card comes into view; follows theme tokens, no dark-theme rules). `js/stats.js` unchanged.
- Tested with the preview emulator and invented data (Chromium screenshots: phone 390 px light, desktop 1100 px dark). NOT tested on the owner's real data, real Jekyll, Safari or a real phone.
- `sw.js` v92 (CSS changed).
- Changed files: `_includes/stats-trend.html`, `css/main.css`, `sw.js`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 10.8 (Streams page: line chart "Plays over time")
- Owner brief: next to what the Streams page has now, add a line chart of all plays from the start to now.
- New `_includes/stats-trend.html`, used in `streams.html` between the black panel and the platform cards. It reads the same `_data/platforms/*` as the cards (no new data file): per year the plays of all music platforms are added, then a running total is drawn, one point per year; the field "Earlier" is the first point, with no "Earlier" numbers the line starts at 0. Years after the last year with numbers are not drawn. Hidden when fewer than two periods have numbers.
- YouTube is NOT in the chart on purpose: it has only one total, no yearly numbers. The heading line says "Music platforms, total by year".
- Drawn at build time: SVG line and area (`preserveAspectRatio="none"`, non-scaling stroke), dots and years are HTML placed by percent. Under the chart a list shows every point as a full number with commas, and the gain of the year (rule 4: no rounding, so the chart has no axis numbers). Liquid has whole numbers only, so x and y are worked out in a 0..1000 box (prefix `tr_`).
- `css/main.css`: new section 10.8 at the end (monochrome, follows the theme tokens, so no dark-theme rules). `js/stats.js`: `.trend` added to the watched cards; the line is drawn left to right when the card comes into view (`clip-path`), dots follow. No animation with "reduce motion".
- Tested with the preview emulator and invented data (Chromium screenshots: phone 390 px light, desktop 1100 px dark). NOT tested on the owner's real data, real Jekyll, Safari or a real phone.
- `sw.js` v91 (CSS and JS changed).
- Changed files: `_includes/stats-trend.html` (new), `streams.html`, `css/main.css`, `js/stats.js`, `sw.js`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete.

## 10.7 (rewrite of "How to read these numbers", April 2025 places)
- Owner brief: the paragraph was clumsy and the importance of the figure got lost; add that in April 2025 he was on places 4 to 5 among all phonk artists on Pandora.
- `top-phonk-artist.html`: the section is now three short paragraphs (what the figure means and the place; April 2025, places 4 and 5; one-moment note). The sentence "There is one snapshot so far" is removed because it did not fit the April 2025 fact. The April 2025 fact is the owner's statement, not a Ledgertone snapshot on this site.
- Changed files: `top-phonk-artist.html`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete. `sw.js` unchanged.

## 10.6 (date of the information on the Ledgertone page)
- Owner brief: in the first paragraph of the page say that the information is from a certain date; in "The numbers" show the date when it was.
- `top-phonk-artist.html`: first paragraph now starts with "This information is from {{ page.lt_snapshot }}."; the last item of "The numbers" is now "Date of these numbers: {{ page.lt_snapshot }}". Both read `lt_snapshot`, so a new snapshot updates them.
- Changed files: `top-phonk-artist.html`, `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`. Nothing to delete. `sw.js` unchanged (no CSS or JS change).

## 10.5 (key line moved from the footer to the home page)
- Owner brief: take the line out of the footer, put it on the home page in the block of the most important short information; drop "very", add "fast-growing"; the owner will add the confirmations soon.
- `_includes/footer.html`: the line of 10.4 is removed (the Ledgertone and CDRA line stays).
- `index.html`: in the About block, above the owner's callout, a new `<p class="callout callout--key">`: `SETTWOR is an active and fast-growing phonk and Brazilian funk producer: N releases since YEAR, M of them in THIS YEAR. No. X in Phonk on Pandora (Ledgertone, DATE).` Same real data as in 10.4 (releases counted from `_releases`, place and date from `lt_*` in `top-phonk-artist.html`). The link is relative (`/top-phonk-artist.html`), not localhost.
- `top-phonk-artist.html`: the sentence "this page does not say that the numbers are growing" is replaced, so the page does not contradict the home page.
- "Fast-growing" is the owner's wording and is not yet backed by data on the site (one Ledgertone snapshot): confirmations are to be added by the owner (a second snapshot with dates).
- `sw.js` v90.

## 10.4 (footer line: very active phonk and Brazilian funk producer)
- Owner brief: say on all pages that he is a fast-growing and very active artist in phonk and Brazilian funk.
- `_includes/footer.html` (so: every page): one line built from real data, no typed numbers: `SETTWOR is a very active phonk and Brazilian funk producer: N releases since YEAR, M of them in THIS YEAR. No. X in Phonk on Pandora (Ledgertone, DATE).` N, YEAR and M are counted from the folder `_releases`; X and DATE are read from the front matter (`lt_*`) of `top-phonk-artist.html`, so a new Ledgertone snapshot changes the footer too.
- `_config.yml` (site description) and `_includes/person-jsonld.html` (artist description): the word "active".
- "Fast-growing" is NOT written on purpose: there is one Ledgertone snapshot, so growth cannot be shown. Add it when a second snapshot shows it.
- Not done here because the texts are in Pages CMS (`_data/home.yml`, `_bio`): the same wording for the home page lead and the biographies, given to the owner as text.
- `sw.js` v89.

## 10.3 (page: SETTWOR in the top phonk artists on Pandora)
- Owner brief: a page that says SETTWOR became one of the top phonk artists and is entering the top of Brazilian funk, with the Ledgertone information.
- New page `top-phonk-artist.html` (`/top-phonk-artist.html`). Figures are only those on https://ledgertone.github.io/settwor.html (snapshot 2026-10-25): 23,000 listeners over 28 days on Pandora, place 10 of 2,759 in Phonk (132 ranked), place 7 of 1,887 in Brazilian Phonk (44 ranked).
- The figures live in the front matter at the top of the file (`lt_*`), the text, the questions and the JSON-LD (WebPage, FAQPage, the artist) all read them. For a new Ledgertone snapshot change them there.
- Said on the page on purpose: it is one snapshot, not live; the place counts only artists with a number; Ledgertone is run by SETTWOR, who is placed by the same rule as everyone. No claim of growth, because there is one snapshot only. The word "hand" is not used.
- Link "Top phonk artist" added to the left column (`_includes/rail-start.html`, block "On this site"); the page is in `sitemap.xml`.
- `sw.js` v88.

## 10.2 (new favicon, sizes for Google and other platforms, site name)
- Owner brief: new favicon (`favicon22.png`, grey film-strip mark), several sizes for Google and other platforms, and make Google show the site as SETTWOR and not as GitHub.
- New files (all drawn from the owner's 256 px picture, smoothed to a clean shape, grey `#898989`, transparent): `favicon.ico` in the root (16, 32, 48), `images/favicon-48.png`, `favicon-96.png`, `favicon-192.png`, `favicon-512.png`, `images/favicon.png` (96 px, same name as before, kept for `sw.js`), `images/apple-touch-icon.png` (180 px, on white, because iOS fills transparency with black), `site.webmanifest` (name SETTWOR, icons 192 and 512).
- `_layouts/default.html`: `<link rel="icon">` for ico, 48, 96 and 192, apple-touch-icon, `<link rel="manifest">`.
- `index.html`: the `WebSite` node got `"alternateName": "SETTWOR Official Site"` (it already had `"name": "SETTWOR"`, `og:site_name` and `application-name`). This is what Google reads for the site name in results.
- Not in the zip's control: Google decides when to re-read the icon and the site name (days to weeks). Ask for indexing of the home page in Search Console after the release.
- The 512 px file is made from a 256 px source (shape redrawn smooth, no blur), a vector original would be better.
- `images/` is new in the bundle: the zip contains ONLY these icon files from that folder, other pictures stay on GitHub.
- `sw.js` v87.

## 10.1 (footer: projects in one line)
- Owner brief: the two footer lines about Ledgertone and CDRA took too much room; shorten, keep both links clear to Google.
- `_includes/footer.html`: one line, `Projects by SETTWOR: Ledgertone: SETTWOR on Pandora (RU) · CDRA: stream milestone awards`. The three links are the same as before (`ledgertone.github.io/settwor.html`, `settwor-ru.html` with `hreflang="ru"`, `cdras.github.io/`). Removed the sentences "listed in the Ledgertone ranking..." and "Ledgertone is run by SETTWOR": the relation stays in JSON-LD (`founder` in `ledgertone-jsonld.html`, `subjectOf` and `sameAs` in `person-jsonld.html`), which was not changed.
- Font size of the line not changed (the owner did not answer that question).
- `sw.js` v86.

## 10.0 (link to CDRA)
- Owner brief: tie settwor.github.io and https://cdras.github.io/ (CDRA, stream milestone awards) together both ways, so Google sees one entity.
- Visible link in the footer (`_includes/footer.html`), under the Ledgertone line: `CDRA — stream milestone awards for SETTWOR`.
- `_includes/person-jsonld.html`: `https://cdras.github.io/` added to `sameAs` of the artist. The artist node already had `"@id": "https://settwor.github.io/#artist"` (`{{ site.url }}/#artist`), so nothing to add there; CDRA's JSON-LD can point to it.
- `sw.js` v85.

## 9.9 (mobile menu: no lag when opening)
- Owner report: the animation lags when the burger menu opens on a phone.
- Cause: `.mobile-menu` is a full-screen layer with `backdrop-filter: blur(20px) saturate(180%)`, and the spring in `js/main.js` moves it on every frame. On phones the browser has to blur the page behind it again on each frame.
- Fix (CSS only, `css/main.css`): the menu has a solid background (`--color-bg`, light and dark) and no backdrop blur; `will-change: transform` only while `.is-open`; `overscroll-behavior: contain` so the page behind does not scroll or bounce. The slide, the spring, the swipe to close and the link entrance are unchanged. `sw.js` v84.
- Look: the menu is no longer see-through (before it was 90 percent opaque with blur). If the owner wants the glass back, return `--mat-chrome-bg-thick` and the blur only for devices that are not phones.
- Not tested on a real phone (checked by reading the code only).

## 9.8 (biographies rewritten, content only)
- Owner brief: rewrite the biographies in all six languages so they read like a person wrote them, without removing any information. Rules: `BIO-WRITING-RULES.md`. Files: `_bio/en.md`, `ru.md`, `pl.md`, `es.md`, `pt.md`, `uk.md` (content files, delivered separately, NOT part of the site zip). `uk.md` follows `ru.md`.
- What changed: only the wording of the body text, the `highlights` texts and the `faq` answers. Removed: em dashes in the body (replaced by commas, colons, full stops), AI-tell words and phrases (breakthrough/turning-point wording, "significance" sentences, closing morals, stacked adjectives), Title Case headings (en), promotional headings ("2025 — Turning point" is now "2025", "2026 — Year of records" is now "2026"). Same facts, dates, numbers, names and links. The artist's Telegram quote is unchanged.
- Chronology fix inside the YouTube channel paragraph: the dates are now listed in time order (5 million views on 24 May 2023 comes before 10,000 subscribers on 11 June 2023). Same dates as before.
- Checked by script against the old files: every number and every link target is still present in each language. Not checked: the live build, the look of the pages.
- Kept on purpose, to ask the owner: the `faq` questions stay in question form (they are a FAQ block); section titles "Значимые работы" / "Значущі роботи" are unchanged; the Polish quote translation keeps its own dashes (it is the artist's words); differences between languages are kept as they were (see the chat summary).

## 9.7 (home screen name)
- The name under the icon when the site is added to the iPhone home screen is now `SETTWOR` (`apple-mobile-web-app-title` and `application-name` in `_layouts/default.html`). Before, iOS took the page title. If the icon was already added, remove it and add it again: iOS keeps the old name. `sw.js` v83. Files: `site/_layouts/default.html`, `site/sw.js`, `site/VERSION`, `site/CHANGELOG.md`.

## 9.6 (fluid interface: one spring system; one Big request)
- Owner brief: make the interface "alive" like the Ledgertone site: one small system in JavaScript without libraries, all motion on springs, answering a press at once (Apple, "Designing Fluid Interfaces"). Done as the new file `js/fluid.js` (about 33 KB with the comments, about 21 KB without comments and indentation), loaded before `js/main.js`.
- Engine (section 1): every animated element has channels `x y s sx r o` (position `p`, speed `v`, target `t`, frequency `w` = 2 pi / response, damping `z`). One shared `requestAnimationFrame` loop, semi-implicit Euler `v += (-w*w*(p-t) - 2*z*w*v)*h; p += v*h`, a step of at most 4 ms, `dt` at most 50 ms. A new target keeps the position and the speed on the screen, so every motion can be caught and turned round. When all channels are back at the CSS value the state is deleted and `translate`, `rotate`, `scale`, `opacity`, `will-change` and the transform origin are cleaned. API: `to(el, targets, {t, z, delay, origin, v, done})`, `set(el, values)`, `jump(el, values, speed)`; extra: `get`, `stop`, `glide`, `appear`. Deviation from the brief: the engine writes the separate CSS properties `translate`, `rotate`, `scale` (not one `transform` string), because this site already has CSS transforms on the same elements (cover tilt, hover lift, reveal) and a `transform` string would overwrite them; browsers without those properties get the one string.
- Press (section 2): REPLACES the 9.5 layer (section 11 of `main.js` is now a pointer). Same rules of who answers (control or card, then text, then section; same selectors), now on springs: going in 0.22 s, back 0.4 s, damping 1. Buttons, tabs, language links and chips (before: CSS `:active`) shrink by `1 - clamp(0.02 .. 0.045, 5 / width)` from `pointerdown`. A press is kept per `pointerId` (several fingers). The press is cancelled when the pointer is more than 10 px outside the element and comes back when it returns. Browser drag of the photo and of button-like links is switched off, so that this works with a mouse.
- Text fix (same version, after the owner's remark "text does not spring"): a press on a paragraph, heading or list item now also shrinks it on a spring (`TEXT` in the settings: 10 px in total, 1 to 3.5 percent) together with a dip to 0.82, before it only dimmed.
- Hover (section 3, mouse and pen only): buttons grow to 1.025 and lean up to 2.5 px to the pointer (factor 0.12); the name in the left rail slides 2.5 px; the arrow of "All ..." links and of the back button shoots out 3 px and returns.
- Avatar (section 4, the round photo): hover 1.07, press sinks, held and moved more than 8 px it is dragged 1:1 (scale 1.1, turn = shift * 0.14), up to 18 px as it is, beyond that a rubber band; on release the spring gets 55 percent of the speed of the last 100 ms (at most 3000 px/s) with damping 0.8: the only bounce on the site.
- Lens (section 5): in the tracklist of the release window one highlight glides from row to row on a spring (it replaces the grey hover fill); on touch a ripple opens from the touch point.
- Year tabs (`main.js` 5a): the indicator is moved by `glide` (x, y and a stretch `sx`), not by CSS `left/width` transitions; caught in the middle of a move it stretches and squeezes instead of jumping.
- Reveal on scroll: cards and photos come in from 12 px below and transparent on a 0.5 s spring, delay `index * 24 ms`, at most 14 steps. The CSS hidden state is now only transparent, so nothing moves twice.
- Keyboard: Enter and Space press a control the same way as a mouse.
- Reduced motion: no scale, shift or springs: a press is a short opacity dip to 0.72, entrances are the plain fade of the CSS, lens and indicator just arrive.
- `html.fluid` (class set by `fluid.js`): the CSS `:active` scale, the arrow and avatar hover transforms, the indicator transitions and the tracklist hover fill carry `html:not(.fluid)`, so they are the fallback only. New CSS block 9.6 at the end of `css/main.css`.
- Not done on purpose: hero entrance and page titles stay CSS keyframes (they must show without JavaScript); the cookie notice keeps its own materialization (glass blur + the `hidden` attribute, no removal, so no clone is needed); the site has no search field, no table and no theme icon, so "breathing field", "row lens in tables" and "icon turn" have no place (the lens is used in the tracklist instead). The theme switch is three text buttons without an indicator.
- Files: `site/js/fluid.js` (new), `site/js/main.js` (press layer removed; reveal, year indicator and `data-lens` call the new file), `site/css/main.css`, `site/_layouts/default.html` (one `<script>`), `site/sw.js` v82 (new file in `START_FILES`), `site/VERSION`, `site/CHANGELOG.md`, `site/AI-NOTES.md`. Nothing to delete by hand.
- Checked in Chromium (Playwright) on the site built by `tools/preview.py`: press 0.955 on a button after 430 ms, cancel when leaving and resume on return, catching a press mid-return (scale 1.02 -> 0.992 -> 0.956 with no jump), hover 1.025 and 1.07, avatar drag (144 px of hand = 64 px shown, 9 degrees), release leaves no inline style, cards, links and text, reveal sequence, year indicator travelling and stretching, lens gliding and fading, touch ripple removed after release, Space on a button, reduced motion (no scale or shift), no page errors. One bug found and fixed in this round: the bare name `STW` in `main.js` is a local variable there (`window.STW` is the one to use before section 10).
- NOT checked: how it FEELS (numbers come from the brief, no video was watched), a real iPhone and Android phone, Safari and Firefox, the photo viewer and release window gestures (skipped zones, unchanged), real Jekyll, the live site.
- To tune: the block "settings of the layers" at the top of section 2 in `js/fluid.js`; the engine settings at the top of section 1.

## 9.5 (press layer: everything answers a press; one Middle request)
- Owner: "make every text, button and section alive, so that it reacts to a finger and to a mouse on press, but without overdoing it". Done as ONE shared layer, not as many separate rules: `js/main.js` section 11 (settings and the rules are written at the top of that section).
- What answers a press now (one element per press, chosen in `resolve()`: a control or card first, then text, then section):
  - cards, covers, photos, big links (news card, release, platform card, YouTube tile, black number panel, FAQ item ...): shrink by about 8 px in total (scale 0.97 to 0.992, smaller for bigger cards), around the centre;
  - small links (footer, left rail, brand, burger ...) and FAQ questions: opacity 0.55;
  - paragraphs, headings, list items, table cells that are not inside a card or link: opacity 0.75;
  - whole sections (blank space between things): shrink by about 3 px around the press point, barely seen.
- Hover is not touched: only a press reacts, so nothing moves under a resting mouse.
- Left to the CSS on purpose (they already had press rules): `.btn`, year tabs, language links, "all news" links. Skipped zones (own gestures): release window, photo viewer, mobile menu, cookie notice, notification ask, form fields.
- How it works: Web Animations on `scale` and `opacity` only (the properties `transform` and `transition` of the components are not touched, so tilt, reveal and hover keep working); going in 90 ms, coming back 340 ms; the animation is cancelled after release, so nothing stays on the element. Touch: the reaction shows after 70 ms, so the start of a scroll never flashes; a quick tap still shows for 90 ms. Moving more than 8 px, scrolling, a context menu or a drag gives the press up (text selection by mouse keeps working). Reduced motion: no movement, only an opacity dip of 0.7 (sections: nothing).
- `css/main.css` (end of file): `-webkit-tap-highlight-color: transparent` on links and buttons, so the browser's grey tap flash does not double the new feedback.
- Files: `site/js/main.js` (new section 11 at the end, header index line), `site/css/main.css` (new block at the end), `site/sw.js` v81, `site/VERSION`, `site/CHANGELOG.md`, `site/AI-NOTES.md`. Nothing to delete by hand.
- Checked in Chromium (Playwright) on the site built by `tools/preview.py` (home, releases, streams, photos): with a mouse, with touch events (CDP) at 390 px and with reduced motion. Every kind above reacts as listed; after release no animation is left and `transform-origin` is restored; a drag of more than 8 px and the start of a scroll give the press up; a quick tap shows; a click on a FAQ question still opens it; no page errors. (Bugs found and fixed in this round: a quick tap showed nothing, and text inside a card dimmed only the paragraph instead of the card.)
- NOT checked: how it FEELS (numbers are chosen by reading, no video was watched), a real iPhone and Android phone, Safari and Firefox (the `scale` property animation needs Safari 14.1+, Firefox 72+, Chrome 104+; older browsers keep the CSS rules only), the release window and photo viewer (skipped zones), real Jekyll, the live site. The preview has no pictures, so photo tiles were tested with the placeholders it makes.
- To tune: change the numbers in section 11.1 of `js/main.js` (`TILE`, `SECTION`, `DIP_OPACITY`, `TEXT_OPACITY`, `DOWN_MS`, `UP_MS`). To add or remove an element from the layer: the selectors in 11.2.

## 9.4 (dark theme: softer page colour; one Very small request)
- Owner: the black page background on the dark theme is too dark. The page is now a dark grey instead of pure black, in both token lists of `css/main.css` section 6.4 (the system dark block and `[data-theme="dark"]`, kept in step):
  - page `--color-bg` `#000` -> `#1a1a1a`; cards `--color-surface` `#1c1c1e` -> `#2a2a2a`; hover `--color-hover` `#2c2c2e` -> `#363636`; soft line `--color-line-soft` `#2c2c2e` -> `#3a3a3a`; line `--color-line` `#6b6b6b` -> `#7a7a7a` (so lines keep about 3:1 against the lighter cards).
  - header, menu and notice materials follow: `rgba(18, 18, 18, ...)` -> `rgba(26, 26, 26, ...)`, banner `rgba(28, 28, 30, ...)` -> `rgba(42, 42, 42, ...)`.
  - phone browser bar (`theme-color`, dark): `#000000` -> `#1a1a1a` in `_layouts/default.html` and `COLORS` in `js/main.js`.
- Left as it was on purpose: the black number panel and black icons (they now stand out against the grey page, the white edge stays), the modal sheet `#0d0d0d`, the light theme. The more contrast and reduced transparency blocks use tokens and follow by themselves.
- This is one value picked by the owner's words, not by eye: if it is still too dark or now too light, change `--color-bg` (and the `rgba(26, 26, 26, ...)` tokens) in both lists. Item 12.1 of `todo design.md` (dark theme audit) is NOT started or marked done.
- Files: `site/css/main.css`, `site/_layouts/default.html`, `site/js/main.js`, `site/sw.js` v80, `site/VERSION`, `site/CHANGELOG.md`, `site/AI-NOTES.md`. Nothing to delete by hand.
- NOT checked: by eye in a browser (no screenshot was taken), real phone, other pages in dark, real Jekyll, live site. Contrast was calculated, not looked at: text `#fff` and grey `#a6a6a6` on the page and on cards stay well above 4.5:1, lines about 3.4:1 on cards.

## 9.3 (link to the Ledgertone pages; one Very small request)
- Owner pasted a fragment from the Ledgertone project (`settwor-site-snippet.html`) and asked to put it into the site. It links the site with the two Ledgertone pages about SETTWOR so that search engines and AI answers see one artist. Nobody can guarantee that Google or an AI answer will use it.
- The fragment was NOT pasted as is: it declares the artist as `MusicGroup` with `@id` `/#artist`, but the site already prints the artist as `Person` with the same `@id` (`_includes/person-jsonld.html`). Two nodes with one `@id` and two types would conflict, and its `sameAs` repeats what the Person already has. So it was merged into the existing data:
  - `_includes/person-jsonld.html`: new `subjectOf` list with the English and the Russian Ledgertone page (printed wherever the Person is printed: home, Streams, biographies).
  - `_includes/ledgertone-jsonld.html` (new): the `Organization` node for Ledgertone, `founder` points to `/#artist`. Printed once, in the home page graph.
  - `index.html`: includes the new file at the end of the `@graph`.
  - `_includes/footer.html`: the visible paragraph with the links to both Ledgertone pages (a second `footer-copy` line after the copyright line, no new CSS).
- No figures in the fragment, so nothing has to be changed when Ledgertone publishes a new snapshot.
- Files: `site/index.html`, `site/_includes/person-jsonld.html`, `site/_includes/ledgertone-jsonld.html` (new), `site/_includes/footer.html`, `site/sw.js` v79, `site/VERSION`, `site/CHANGELOG.md`, `site/AI-NOTES.md`. Nothing to delete by hand.
- Checked: the home page graph (WebSite, ProfilePage with the Person, ImageObject, Organization) was assembled from the real include files by a small script (Liquid loops replaced by test URLs) and parsed as JSON: valid, one `#artist` node, no duplicate typed `@id`, `founder` points to `/#artist`; the footer tags are balanced. The Streams page and the biographies were not rendered, they print the same Person include. NOT checked: real Jekyll, `tools/preview.py`, Google Rich Results Test, live site, the look of the footer line by eye.

## 9.2 (Phase 12 added to the plan; plan only; one Very small request)
- Owner request: add to the todo list "make the dark theme look better" and "improve the mobile version". Written into `todo design.md` as Phase 12 (note 44): 12.1 dark theme (audit first, then the owner picks, then fixes in both token places) and 12.2 mobile version (audit at 320, 375 and 430 px first, the owner picks what to fix). Both are vague, so no look was guessed.
- No site code changed. Files: `todo design.md`, `START-HERE.md`, `site/AI-NOTES.md`, `site/CHANGELOG.md`, `sw.js` v78, `VERSION`, `history/CHANGELOG-ARCHIVE.md` (entry 8.9 moved here unchanged).
- NOT checked: the live site, a browser, real phones, real Jekyll (nothing was run; the line numbers in 12.1 come from `grep` on `css/main.css`).

## 9.1 (Phase 11 extended; plan only; one Small request)
- Second research round (Google Search Central, GitHub, music sources) and the owner's choices written into `todo design.md`: 11.1 now covers ALL releases (with a thin-page risk note), new 11.4 site name (`alternateName` in the `WebSite` node) and site icon, new 11.5 `/links/` page for the Instagram and TikTok bio link, new 11.6 the owner's outside checklist (artist profiles on Spotify, Apple Music and YouTube; MusicBrainz and Discogs; Genius and Last.fm; claim the Knowledge Panel when it exists).
- Corrections to the 9.0 notes: Google's favicon rule is a square of at least 8 by 8 px with larger than 48 by 48 recommended (not "a multiple of 48"); `lastmod` only when the dates are accurate, `priority` and `changefreq` are ignored.
- No site code changed. Files: `todo design.md`, `START-HERE.md`, `site/AI-NOTES.md`, `site/CHANGELOG.md`, `sw.js` v77, `VERSION`, `history/CHANGELOG-ARCHIVE.md` (entry 8.8 moved here unchanged).
- NOT checked: the live site; the GitHub docs themselves about the `github.io` redirect (seen only in community discussions); real Jekyll.

## 9.0 (Phase 11 added to the plan; plan only; one Small request)
- Audit of the site (read from the code, live site not opened) and the owner's choices written into `todo design.md` as Phase 11 (note 43): 11.1 release pages (own address per release), 11.2 old files out of the root (`sitemap1.xml`, `1.txt` and similar; `start.bat` is kept but should not be published), 11.3 press kit page `/press/`. Audience noted: mostly USA, then probably Brazil.
- No site code changed. Files: `todo design.md`, `START-HERE.md`, `site/AI-NOTES.md`, `site/CHANGELOG.md`, `sw.js` v76, `VERSION`, `history/CHANGELOG-ARCHIVE.md` (entries 8.1 to 8.7 moved here unchanged).
- NOT checked: the live site, `_config.yml` (not in the zip: whether `releases` has `output: true`), which old files are really published, Search Console, real Jekyll.
