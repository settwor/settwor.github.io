# AI-NOTES: read this first (for any AI or developer who gets this site)

This file is the memory of the project. It is NOT published on the website (it is in `exclude` in `_config.yml`).

## The line to paste into a new chat (the owner can copy it)

> Это мой сайт (архив). Сначала прочитай AI-NOTES.md и CHANGELOG.md и следуй правилам оттуда. После любых изменений: подними версию в VERSION, допиши CHANGELOG.md, обнови разделы "Open items" и "Hints for the next chat" в AI-NOTES.md, и назови архив settwor-site-vX.Y.zip (X.Y = новая версия сайта).

English: "This is my site (archive). Read AI-NOTES.md and CHANGELOG.md first and follow them. After every change: raise the number in VERSION, add an entry to CHANGELOG.md, update "Open items" and "Hints for the next chat" in AI-NOTES.md, and name the archive settwor-site-vX.Y.zip (X.Y = the new site version)."

## Rules from the owner (always follow)

1. Talk to the owner in Russian. The website itself is in English.
2. Name every archive with the SITE version: `settwor-site-v2.4.zip`. Never "archive 3". Every change raises the version by 0.1 (`VERSION` file, entry in `CHANGELOG.md`).
3. The public website must never say or hint that numbers are typed or entered by hand. Not on the page, not in tooltips. (It does not build trust.) Comments in code and CMS field names are fine, visitors do not see them.
4. Numbers are shown in full with commas (16,234,264). Never round, never "2M+".
5. Black panel: the BIG number = music platforms + YouTube RELEASE videos. Under it a smaller number = music platforms + the WHOLE YouTube channel (release videos + all other videos). The bar and the list under the numbers show only music platforms and release videos, never the other videos. The YouTube section of the Streams page shows the whole channel, release videos and other videos. Owner's decision, v2.0 (it replaced v1.6 and v1.8).
6. Look: monochrome black and white site. Only the platform colours (logos) are coloured. Everything must be neat, even, same-size cards, no crooked layouts.
7. Do not guess links. Only put a platform URL if it was checked (the artist name, Kryvyi Rih, born 8 Feb 2007). A wrong link is worse than none.
8. Deliver: a zip with ONLY the code, templates, styles, scripts and config that changed (full paths), so the owner can unzip over the folder. Say which file must be deleted by hand.
   **NEVER put content or data files in the zip**: `_data/*.yml`, `_data/platforms/*`, `_data/auto_stats.json`, `_posts`, `_releases`, `_bio`, `_config.yml` values the owner may have changed. The owner edits them in Pages CMS and the live copy is on GitHub, so a zip overwrites their work (this happened in versions 1.1 to 1.6 and wiped the plays the owner had entered). Make templates work with defaults instead. If a new data file is truly needed, do not zip it: tell the owner to create it in Pages CMS, or give it as a separate file marked "create only if missing".
9. If you could not test something (the live site, the YouTube API, real Jekyll), say so plainly.
10. The owner has NO SoundCloud. Never add SoundCloud anywhere (links, platform lists, colours, search buttons). Removed in v2.7.

## What the site is

- Official site of SETTWOR (phonk and Brazilian funk producer, Kryvyi Rih, Ukraine, based in Poland). Address: https://settwor.github.io (GitHub Pages, repository `settwor.github.io`).
- Jekyll (the `github-pages` gem, Jekyll 3, Liquid 4). No plugins beyond GitHub Pages. Pictures are not in the archive (the owner removes them).
- Content is edited by the owner in **Pages CMS** (`.pages.yml`). Texts live in `_data/*.yml`, news in `_posts`, releases in `_releases`, biographies in `_bio`.
- The service worker `sw.js` caches CSS/JS. **When CSS or JS changes, raise `VERSION` in `sw.js`** (const VERSION = 'v12' since 2.4), or visitors see old styles.

## Local preview (the owner works on Windows)

- `start.bat` -> `tools/serve.py` -> `tools/preview.py <site> <site>/_preview`, then serves it.
- `tools/preview.py` is an EMULATOR of Jekyll written in Python, not real Jekyll. It supports only part of Liquid. If it crashes with `unsupported filter/tag`, either add the filter to `FILTERS` in `preview.py` or avoid it. Real GitHub Pages can still fail where the preview works, so ask the owner for the log of Actions > "pages build and deployment" if the live site does not update.
- Already added to the preview: divided_by, times, modulo, floor, ceil, round, abs, at_least, at_most, Ruby-like `split` (drops empty pieces at the end), negative `slice`, nil/"" counted as 0 in numbers and comparisons, `.json` and sub-folders in `_data`.
- Not supported by the preview: `case/when`. Do not write `a contains b == false`, use `unless`.
- Liquid: `assign` inside an include is global; use unique variable names (the prefixes `st_`, `nf_`, `p_`).

## The numbers system (the main work so far)

Pages: the home page shows only the black panel (a link) before the news; `/streams.html` shows everything.

Data and flow:
- Music platforms: one file per platform in `_data/platforms/<key>.yml` (the owner's live data, never ship them) with `y2027 ... y2021`, `earlier`, optional `url`. Keys: spotify, apple_music, pandora, youtube_music, deezer, amazon_music, tidal, yandex_music, vk_music, other. A year or platform left empty is not shown. The owner edits them in Pages CMS > group "Streams".
- YouTube: `tools/fetch-stats.py` (GitHub Action `.github/workflows/stats.yml`, about every two weeks (1st and 15th), secret `YOUTUBE_API_KEY`) writes `_data/auto_stats.json`: `clips_views` (releases playlist, only videos of the own channel), `other_views` (= channel total minus clips_views), `channel_total_views`. Setup (handle, playlist id) is in `_data/streams.yml`; `clips_views_fallback` / `other_views_fallback` are used only while `auto_stats.json` is missing.
- Maths (`_includes/stats-calc.html`): music total = sum of all platform years; YouTube whole channel = clips + other; grand total = music + whole channel (no double counting). In the black panel the BIG number is `st_panel_total` (music + YouTube release videos); the smaller number under it is `st_total` (music + whole channel, no double counting). The bar and the list use `st_rows_all` (music platforms + release videos only). Owner's decision, v2.0. Platforms are sorted biggest first by building strings `"000000123456|key|Name~"` and sorting them.
- Artist links (defaults, CMS link wins): `_includes/artist-urls.html` gives `au_spotify`, `au_apple`, `au_pandora`, `au_ytm`. Used in the right column ("Listen to SETTWOR"), the footer, JSON-LD `sameAs` and the Streams page.
- Home hero (v2.3): name, tagline, note, button "Listen on Spotify" and a row Apple Music / YouTube Music / Pandora. "Newest release" button was removed by the owner; do not bring it back. Phone styles are at the end of `css/main.css` (section "2.3").
- Biographies: one file per language in `_bio` (en, ru, pl, es, pt, uk). A new language = a new file with `lang`, `lang_name`, `order`; the list, footer, hreflang and sitemap follow by themselves. Block titles per language are in `_data/bioui.yml` (Ukrainian ones are built into `_layouts/bio.html`). `_bio/uk.md` is a translation of `ru.md`; when `ru.md` changes, `uk.md` must change too.
- `js/stats.js` watches every card separately (not the whole block). Do not go back to one observer for the whole `#numbers`: on the Streams page it is taller than 5 screens and would never start.
- Includes: `stats-calc.html` (all numbers), `stats-panel.html` (black panel, `link=` makes it clickable), `stats-block.html` (home section), `stats-details.html` (cards and YouTube tiles), `num-full.html` (full number with commas, no rounding).
- Colours: CSS classes `c-<key>` in `css/main.css` (Spotify green, Apple Music pink, Pandora blue, Deezer purple, Amazon cyan, TIDAL white/black, Yandex yellow, VK blue, YouTube reds). Pandora's brand colour is blue, not purple.
- `js/stats.js`: count-up, bars grow, cards appear. Layout adapts with a CSS container query (`.numbers { container: numbers / inline-size }`).
- The Streams page also has "Official profiles" (links from `_data/links.yml` plus platform `url`s, `rel="me"`) and schema.org JSON-LD. Do not add text explaining how numbers are counted (the owner removed it).

## File map (only what matters)

- `index.html` home; `streams.html` Streams page; `releases.html`; `photo.html`; `_layouts/`; `_includes/` (header, footer, rails, stats-*).
- `_data/home.yml`, `pages.yml` (page headings), `links.yml` (official channels), `streams.yml`, `platforms/`, `auto_stats.json` (made by the Action, may be missing locally: `git pull`).
- `css/main.css` (one big file), `js/main.js`, `js/stats.js`, `sw.js`.
- `tools/` preview and stats scripts. `docs/` the owner's guides (Russian). `VERSION`, `CHANGELOG.md`, `AI-NOTES.md`.

## Tracklists and lyrics (v2.7)

- Tracklists: field `tracklist` (list of strings) in `_releases/<release>.md`. The release window on `/releases.html` (`js/main.js`, section 9) shows it. Imported in v2.7 from `SETTWOR_Genius_Catalogue.json` (the owner's file, made from Amazon/Apple listings). Verified lists: albums and the EPs up to MENTE LOUCA. The seven 2026 EPs (SE TU QUER ... Vinte E Quatro) are marked "provisional order" in the catalogue: the owner should look at them once. Not imported (no data): Lost Vibe Vol.1 (15 tracks, titles unknown), Want to Be, anguish, Fuck The World, Toma Jatada, the Mc Baiano re-release. BONUSMIX 2024 (21 tracks) is not on the site yet: it needs a cover, so it was not created.
- Lyrics: one file per song in the folder `lyrics/` (`*.md`, front matter `layout: lyrics`, `title`, `artist`, `release`, `permalink: /lyrics/<name>/`; the body is the words, line breaks are kept with CSS `white-space: pre-line`). No change of `_config.yml` is needed: the pages are found with `site.pages | where: "layout", "lyrics"` (`_includes/lyrics-map.html`, `sitemap.xml`). Edited in Pages CMS > Lyrics.
- The "Lyrics" button: `lyrics-map.html` prints `#lyrics-map` (lower-case title -> address) on `/releases.html`; `main.js` matches each track name against it. Trailing version marks like `(sped up)`, `(slowed)`, `[Bonus Track]`, `(Alternate Mix)` are removed, so every version opens the page of the original song. A new lyrics page needs no other step.
- Only one lyrics page exists: `GOT ME UP 2` (moved from the old file `lyrics/GOT-ME-UP-2.html`, which is left in place). Do NOT fetch or write lyrics from the internet: the catalogue has links only, and lyrics must come from the owner.
- `tools/preview.py` now knows `site.pages` and `.md` pages.

## Open items (update this list at the end of every session)

- Checked artist links exist for Spotify, Apple Music, Pandora and YouTube Music (the owner gave Pandora and YouTube Music in v2.1). Missing: Deezer, TIDAL, Amazon Music, Yandex Music, VK Music. The owner can paste them in Pages CMS > Streams > platform > "Your artist page link". To show a new one on the whole site, add it to `_includes/artist-urls.html` and to the blocks that use it (`rail-follow.html`, `footer.html`, `person-jsonld.html`).
- The YouTube API part was never run by an AI (no network). If numbers look wrong, ask for the log of the Action "Update stats" (a failure turns the run red with the reason).
- The live site was never seen by an AI; the owner once reported that the black panel was missing online while it showed locally (likely not pushed, or a Pages build error, or the cached CSS).
- v2.7: the owner should check the seven provisional 2026 EP tracklists, add BONUSMIX 2024 (with a cover) and paste the words of the other songs in Pages CMS > Lyrics. The old files `lyrics/GOT-ME-UP-2.html` and `tracklist/GET-IT,-Vol.1.html` are still online (old design); the owner may delete them or ask for redirects.
- Ukrainian biography `_bio/uk.md` was written by an AI (translation of the Russian one); a native speaker should read it once.
- The "status" on the Streams page is only a small Live / Verified badge. The owner asked for "a status", the exact meaning was not confirmed.

- v2.4 was checked with `tools/preview.py` (a Python emulator) and Playwright screenshots (320, 390, 1100 px), not with real Jekyll and not on the live site. After pushing, hard refresh (Ctrl+F5) once.

## Hints for the next chat (update this section at the end of every session)

- Start by reading `CHANGELOG.md`, then this file. Ask the owner only what you cannot find here.
- Before changing Liquid, run `python tools/preview.py . /tmp/out` (needs `pyyaml` and `markdown`) and look at the HTML. Screenshots with Playwright are a good check (390 px wide and 1100 px).
- Keep each change small, raise the version, write the CHANGELOG entry in plain English: what changed, which files, why.
- If the owner reports a bug, first ask: was it pushed to GitHub, did the Pages build pass, did a hard refresh (Ctrl+F5) help.
